<?php
  require ("../includes/koneksi.php") ;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login | KEDEBOOK </title>
  <link rel="stylesheet" href="asset/css/bootstrap.css">
</head>
<body>
  <section class="vh-100" style="background-color: #eee;">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-lg-12 col-xl-11">
          <div class="card text-black" style="border-radius: 25px;">
            <div class="card-body p-md-5">
              <div class="row justify-content-center">
                <div class="col-md-10 col-lg-6 col-xl-5">
  
                  <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-5">Sign in</p>
  
                  <form class="mx-1 mx-md-4" method="POST" action="prosesforgot2.php">

                  <div class="d-flex flex-row align-items-center mb-3">
                      <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                      <div class="form-outline flex-fill mb-0 mt-5">
                        <input 
                        type="text" 
                        id="username" 
                        class="form-control"
                        name="username"
                        value="<?php echo $_SESSION['username'] ?>">
                      </div>
                    </div>

                    <div class="d-flex flex-row align-items-center mb-3">
                        <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                        <div class="form-outline flex-fill mb-0">
                          <label for="">Password Baru</label>
                          <input 
                          type="password" 
                          id="passwordbaru" 
                          class="form-control"
                          name="passwordbaru"
                          placeholder="Masukkan Password Baru"
                          required data-eye/>
                        </div>
                      </div>

                      <div class="d-flex flex-row align-items-center mb-3">
                        <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                        <div class="form-outline flex-fill mb-0">
                          <label for="">Password Baru</label>
                          <input 
                          type="password" 
                          id="passwordkonfir" 
                          class="form-control"
                          name="passwordkonfir"
                          placeholder="Konfirmasi Password Baru"
                          required data-eye/>
                        </div>
                      </div>
  
                    <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                      <button type="submit" class="btn btn-primary btn-lg" name="btnKirim">Kirim</button>
                    </div>

  
                  </form>
  
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</body>
</html>