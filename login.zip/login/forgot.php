<?php
require("../includes/koneksi.php");

if(isset($_POST['btnCari']))
{
	$user_forgot=$_POST['username'];

	$sql = "SELECT * FROM akun WHERE username = '{$user_forgot}'";
	$query = mysqli_query($koneksi, $sql);

	if(!$query){
		die("Query gagal".mysqli_error($koneksi));
	}
	while ($row = mysqli_fetch_array($query)){
		$user = $row['username'];
		$pass = $row['password'];
		$nama = $row['nama'];
		$email = $row['email'];
    $peran = $row['peran'];
	}
	if($user == $user_forgot){
		header("Location:../login/prosesforgot.php");
		$_SESSION['username'] = $user;
		$_SESSION['nama'] = $nama;
		$_SESSION['email'] = $email;
    $_SESSION['peran'] = $peran; 
    $_SESSION['password'] = $pass;
  } else {
		echo "User tidak ditemukan";
	}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Lupa Password | KEDEBOOK </title>
  <link rel="stylesheet" href="asset/css/bootstrap.css">
</head>
<body>
  <section class="vh-100" style="background-color: #eee;">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-lg-10 col-xl-11">
          <div class="card text-black" style="border-radius: 25px;">
            <div class="card-body p-md-5">
              <div class="row justify-content-center">
                
                <div class="col-md-10 col-lg-6 col-xl-5">
  
                  <p class="text-center h1 fw-bold">Lupa Password</p>
                  <p class="text-center h3 fw-bold ">Cari username</p>
  
                  <form class="mx-1 mx-md-4" method="POST">
  
                    <div class="d-flex flex-row align-items-center mb-3">
                      <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                      <div class="form-outline flex-fill mb-0 mt-5">
                        <input 
                        type="text" 
                        id="username" 
                        class="form-control"
                        name="username"
                        placeholder="Masukkan username Anda"
                        required />
                      </div>
                    </div>
  
                    <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                      <button type="submit" class="btn btn-primary btn-lg" name="btnCari">Cari</button>
                    </div>
  
                  </form>
  
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</body>
</html>