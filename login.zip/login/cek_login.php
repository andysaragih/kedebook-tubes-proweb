<?php
include '../includes/koneksi.php';

if(isset($_POST['btnLogin']))
{
	$user=$_POST['username'];
	$pass_login=$_POST['password'];
  // $password1=password_verify($pass_login, $_SESSION['password']);

  // $pass = password_verify($pass_login, $data['password']);
  $sql = "SELECT * FROM akun WHERE username = '$user'";
	$query = mysqli_query($koneksi, $sql);
  $data = mysqli_fetch_assoc($query);
  $cek = mysqli_num_rows($query);
	}
  if ($cek == 1 && password_verify($pass_login, $data['password']) == 1) {
      if ($data['peran'] == 'Administrator') {
        $_SESSION['peran'] = 'Administrator';
        $_SESSION['username'] = $data['username'];
        $_SESSION['nama'] = $data['nama'];
        $_SESSION['email'] = $data['email'];
        // password_verify($pass_login, $data['password']);
        header('location:../admin/admin.php');
    } else if ($data['peran'] == 'Cashier') {
        $_SESSION['peran'] = 'Cashier';
        $_SESSION['username'] = $data['username'];
        $_SESSION['nama'] = $data['nama'];
        $_SESSION['email'] = $data['email'];
        // password_verify($pass_login, $data['password']);
        header('location:../cashier/store.php');
    } 
  }
else {
    $message = 'Username atau password salah!!!';
    header('location:index.php?message=' . $message);
}
?>